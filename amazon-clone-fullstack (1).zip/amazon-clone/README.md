# 🛒 Amazon Clone — Full Stack (Next.js + Express + MongoDB)

A fully functional e-commerce platform built with **Next.js 14**, **Express.js**, and **MongoDB**.

---

## 📁 Project Structure

```
amazon-clone/
├── backend/              ← Express.js REST API
│   ├── src/
│   │   ├── config/db.js         ← MongoDB connection
│   │   ├── middleware/auth.js   ← JWT auth middleware
│   │   ├── models/
│   │   │   ├── User.js          ← User model
│   │   │   ├── Product.js       ← Product model (with reviews)
│   │   │   └── Order.js         ← Order model
│   │   ├── routes/
│   │   │   ├── auth.js          ← /api/auth (login, register, profile)
│   │   │   ├── products.js      ← /api/products (CRUD, reviews, search)
│   │   │   ├── orders.js        ← /api/orders (place, track, cancel)
│   │   │   ├── users.js         ← /api/users (wishlist, addresses)
│   │   │   ├── payment.js       ← /api/payment (Stripe intent)
│   │   │   └── categories.js    ← /api/categories
│   │   ├── utils/seed.js        ← Seed DB with 30+ products
│   │   └── index.js             ← App entry point
│   ├── .env.example
│   └── package.json
│
└── frontend/             ← Next.js 14 App Router
    ├── src/
    │   ├── app/
    │   │   ├── layout.js                ← Root layout + Header/Footer
    │   │   ├── page.js                  ← Home page (hero, categories, products)
    │   │   ├── search/page.js           ← Search + filter + sort
    │   │   ├── product/[id]/page.js     ← Product detail + reviews
    │   │   ├── cart/page.js             ← Cart with save-for-later
    │   │   ├── checkout/page.js         ← 3-step checkout
    │   │   ├── orders/page.js           ← All orders
    │   │   ├── orders/[id]/page.js      ← Order detail + tracking
    │   │   ├── wishlist/page.js         ← Wishlist
    │   │   ├── account/page.js          ← Profile + addresses
    │   │   └── auth/
    │   │       ├── login/page.js
    │   │       └── register/page.js
    │   ├── components/
    │   │   ├── layout/
    │   │   │   ├── Header.js            ← Sticky header, search, cart badge
    │   │   │   └── Footer.js
    │   │   └── product/
    │   │       ├── ProductCard.js       ← Product card with wishlist toggle
    │   │       └── ProductGrid.js       ← Responsive product grid
    │   └── store/index.js               ← Zustand stores (auth, cart, wishlist)
    ├── next.config.js
    ├── tailwind.config.js
    └── package.json
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (local or [MongoDB Atlas](https://www.mongodb.com/atlas))

---

### 1. Clone and Install

```bash
# Backend
cd amazon-clone/backend
cp .env.example .env          # Edit with your values
npm install

# Frontend
cd ../frontend
cp .env.local.example .env.local  # Edit with your values
npm install
```

---

### 2. Configure Environment

**backend/.env**
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/amazon-clone
JWT_SECRET=your_very_secret_key_here
JWT_EXPIRE=30d
CLIENT_URL=http://localhost:3000
NODE_ENV=development
STRIPE_SECRET_KEY=sk_test_...   # Optional
```

**frontend/.env.local**
```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...  # Optional
```

---

### 3. Seed the Database

```bash
cd backend
npm run seed
```

This creates:
- **30+ products** across 6 categories
- **Admin user**: `admin@amazon-clone.com` / `admin123`

---

### 4. Start Development Servers

```bash
# Terminal 1 — Backend
cd backend
npm run dev          # Runs on http://localhost:5000

# Terminal 2 — Frontend
cd frontend
npm run dev          # Runs on http://localhost:3000
```

Open **http://localhost:3000** 🎉

---

## ✅ Features

### Customer Features
| Feature | Details |
|---|---|
| 🏠 Home Page | Hero carousel, category grid, featured/bestseller products |
| 🔍 Search | Live autocomplete, filter by category/price/rating, sort |
| 🛍️ Product Detail | Image gallery, specs table, reviews, related products |
| 🛒 Cart | Add/remove/update qty, save for later, price breakdown |
| 💳 Checkout | 3-step: Address → Payment → Review → Order |
| 📦 Orders | Full order history, status tracking, cancel order |
| ❤️ Wishlist | Save products, move to cart |
| 👤 Account | Profile edit, address book, password change |
| 🔐 Auth | JWT login/register, persistent sessions |

### Data Persistence
- **Auth state** → localStorage (Zustand persist)
- **Cart** → localStorage (survives page reload)
- **Wishlist** → localStorage + synced to DB on login
- **Recently viewed** → localStorage
- **Orders** → MongoDB (permanent)
- **Addresses** → MongoDB

### Backend API Endpoints
```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/me
PUT    /api/auth/profile

GET    /api/products               ?keyword, category, minPrice, maxPrice, rating, sort, page, limit
GET    /api/products/:id
POST   /api/products/:id/reviews
POST   /api/products               (admin)
PUT    /api/products/:id           (admin)
DELETE /api/products/:id           (admin)

POST   /api/orders
GET    /api/orders/my
GET    /api/orders/:id
PUT    /api/orders/:id/pay
PUT    /api/orders/:id/cancel
GET    /api/orders                 (admin)
PUT    /api/orders/:id/status      (admin)

POST   /api/users/wishlist/:id
GET    /api/users/wishlist
POST   /api/users/addresses
GET    /api/users/addresses
DELETE /api/users/addresses/:id

POST   /api/payment/create-intent
```

---

## 🛠️ Tech Stack

| Layer | Tech |
|---|---|
| Frontend | Next.js 14 (App Router), React 18, Tailwind CSS |
| State | Zustand with localStorage persistence |
| Backend | Node.js, Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT (jsonwebtoken) + bcryptjs |
| Payments | Stripe (optional) |
| Notifications | react-hot-toast |

---

## 🚢 Deployment

### Backend → Railway / Render
1. Push to GitHub
2. Connect to Railway/Render
3. Set environment variables
4. Deploy

### Frontend → Vercel
1. Push to GitHub
2. Import to Vercel
3. Set `NEXT_PUBLIC_API_URL` to your backend URL
4. Deploy

---

## 📝 Notes

- Cart and wishlist persist in localStorage even without login
- On login, wishlist syncs to user's MongoDB profile
- Admin panel: log in as admin and access `/api/orders`, `/api/products` via REST
- For production: enable HTTPS, use environment secrets, set `NODE_ENV=production`
