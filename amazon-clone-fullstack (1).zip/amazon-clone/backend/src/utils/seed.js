const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const Product = require('../models/Product');
const User = require('../models/User');

const products = [
  // Electronics
  { name: 'Samsung Galaxy S24 Ultra', description: 'Latest flagship smartphone with AI features, 200MP camera, S Pen included', price: 89999, originalPrice: 109999, discount: 18, category: 'Electronics', brand: 'Samsung', images: ['https://picsum.photos/seed/s24/400/400', 'https://picsum.photos/seed/s24b/400/400'], stock: 50, rating: 4.5, numReviews: 234, isFeatured: true, isBestseller: true, isNew: true, tags: ['smartphone', 'android', '5G'], specs: [{ key: 'Display', value: '6.8" Dynamic AMOLED' }, { key: 'RAM', value: '12GB' }, { key: 'Storage', value: '256GB' }, { key: 'Battery', value: '5000mAh' }] },
  { name: 'Apple iPhone 15 Pro', description: 'Titanium design, A17 Pro chip, 48MP main camera with USB-C', price: 134900, originalPrice: 139900, discount: 4, category: 'Electronics', brand: 'Apple', images: ['https://picsum.photos/seed/ip15/400/400', 'https://picsum.photos/seed/ip15b/400/400'], stock: 30, rating: 4.7, numReviews: 456, isFeatured: true, isBestseller: true, tags: ['iPhone', 'iOS', '5G'], specs: [{ key: 'Chip', value: 'A17 Pro' }, { key: 'Camera', value: '48MP Main' }, { key: 'Storage', value: '128GB' }] },
  { name: 'Sony WH-1000XM5 Headphones', description: 'Industry-leading noise cancellation, 30hr battery, multipoint connection', price: 24990, originalPrice: 34990, discount: 29, category: 'Electronics', brand: 'Sony', images: ['https://picsum.photos/seed/sony1/400/400'], stock: 80, rating: 4.6, numReviews: 1203, isFeatured: true, isBestseller: true, tags: ['headphones', 'wireless', 'noise-cancellation'] },
  { name: 'Dell XPS 15 Laptop', description: '13th Gen Intel Core i7, 16GB RAM, 512GB SSD, OLED touch display', price: 149990, originalPrice: 169990, discount: 12, category: 'Electronics', brand: 'Dell', images: ['https://picsum.photos/seed/dell1/400/400'], stock: 20, rating: 4.4, numReviews: 89, isFeatured: true, tags: ['laptop', 'ultrabook', 'OLED'] },
  { name: 'Apple iPad Pro 12.9"', description: 'M2 chip, Liquid Retina XDR display, 5G, with Apple Pencil support', price: 99900, originalPrice: 109900, discount: 9, category: 'Electronics', brand: 'Apple', images: ['https://picsum.photos/seed/ipad1/400/400'], stock: 35, rating: 4.8, numReviews: 312, tags: ['tablet', 'iPad', 'M2'] },
  { name: 'Samsung 65" 4K QLED TV', description: 'Neo QLED, Quantum Matrix Technology, built-in Alexa and Google Assistant', price: 129999, originalPrice: 159999, discount: 19, category: 'Electronics', brand: 'Samsung', images: ['https://picsum.photos/seed/tv1/400/400'], stock: 15, rating: 4.5, numReviews: 178, isFeatured: true, tags: ['TV', '4K', 'QLED'] },

  // Clothing
  { name: 'Levi\'s 511 Slim Fit Jeans', description: 'Classic slim fit, sits below waist, slim through hip and thigh, 99% cotton', price: 2999, originalPrice: 4499, discount: 33, category: 'Clothing', brand: 'Levi\'s', images: ['https://picsum.photos/seed/levis1/400/400'], stock: 200, rating: 4.3, numReviews: 567, isBestseller: true, tags: ['jeans', 'men', 'denim'] },
  { name: 'Nike Air Max 270', description: 'Max Air unit in heel for all-day comfort, mesh upper for breathability', price: 8995, originalPrice: 10995, discount: 18, category: 'Clothing', brand: 'Nike', images: ['https://picsum.photos/seed/nike1/400/400'], stock: 120, rating: 4.5, numReviews: 892, isBestseller: true, isFeatured: true, tags: ['shoes', 'sneakers', 'sports'] },
  { name: 'Adidas Ultraboost 23', description: 'Boost midsole for ultimate energy return, Primeknit+ upper, Continental rubber', price: 13999, originalPrice: 16999, discount: 18, category: 'Clothing', brand: 'Adidas', images: ['https://picsum.photos/seed/adidas1/400/400'], stock: 75, rating: 4.6, numReviews: 423, tags: ['running', 'shoes', 'ultraboost'] },
  { name: 'H&M Regular Fit Shirt', description: 'Regular fit shirt in woven cotton fabric, spread collar, button placket', price: 799, originalPrice: 1299, discount: 38, category: 'Clothing', brand: 'H&M', images: ['https://picsum.photos/seed/hm1/400/400'], stock: 500, rating: 3.9, numReviews: 234, tags: ['shirt', 'formal', 'cotton'] },
  { name: 'Zara Puffer Jacket', description: 'Quilted puffer jacket with hood, zip fastening, side pockets', price: 4999, originalPrice: 6999, discount: 29, category: 'Clothing', brand: 'Zara', images: ['https://picsum.photos/seed/zara1/400/400'], stock: 90, rating: 4.2, numReviews: 156, tags: ['jacket', 'winter', 'men'] },
  { name: 'Puma Dri-FIT T-Shirt', description: 'Moisture-wicking fabric, 100% polyester, perfect for workouts', price: 899, originalPrice: 1499, discount: 40, category: 'Clothing', brand: 'Puma', images: ['https://picsum.photos/seed/puma1/400/400'], stock: 300, rating: 4.1, numReviews: 789, isNew: true, tags: ['tshirt', 'sports', 'gym'] },

  // Books
  { name: 'Atomic Habits by James Clear', description: 'Tiny Changes, Remarkable Results. Proven framework for building good habits', price: 399, originalPrice: 599, discount: 33, category: 'Books', brand: 'Penguin', images: ['https://picsum.photos/seed/book1/400/400'], stock: 1000, rating: 4.8, numReviews: 12453, isBestseller: true, isFeatured: true, tags: ['self-help', 'habits', 'productivity'] },
  { name: 'The Psychology of Money', description: 'Timeless lessons on wealth, greed, and happiness by Morgan Housel', price: 299, originalPrice: 499, discount: 40, category: 'Books', brand: 'Jaico', images: ['https://picsum.photos/seed/book2/400/400'], stock: 800, rating: 4.7, numReviews: 8932, isBestseller: true, tags: ['finance', 'money', 'investing'] },
  { name: 'Rich Dad Poor Dad', description: 'What the Rich Teach Their Kids About Money That the Poor and Middle Class Do Not!', price: 249, originalPrice: 395, discount: 37, category: 'Books', brand: 'Plata', images: ['https://picsum.photos/seed/book3/400/400'], stock: 1200, rating: 4.6, numReviews: 22341, isBestseller: true, tags: ['finance', 'entrepreneurship'] },
  { name: 'Think and Grow Rich', description: 'Napoleon Hill\'s classic guide to achieving personal goals and financial success', price: 199, originalPrice: 299, discount: 33, category: 'Books', brand: 'General Press', images: ['https://picsum.photos/seed/book4/400/400'], stock: 900, rating: 4.5, numReviews: 15678, tags: ['self-help', 'motivation', 'success'] },
  { name: 'Deep Work by Cal Newport', description: 'Rules for Focused Success in a Distracted World', price: 349, originalPrice: 499, discount: 30, category: 'Books', brand: 'Piatkus', images: ['https://picsum.photos/seed/book5/400/400'], stock: 600, rating: 4.6, numReviews: 5432, isNew: true, tags: ['productivity', 'focus', 'career'] },

  // Kitchen
  { name: 'Instant Pot Duo 7-in-1', description: 'Electric pressure cooker, slow cooker, rice cooker, steamer, yogurt maker, warmer', price: 6999, originalPrice: 9999, discount: 30, category: 'Kitchen', brand: 'Instant Pot', images: ['https://picsum.photos/seed/kitchen1/400/400'], stock: 150, rating: 4.7, numReviews: 4523, isBestseller: true, isFeatured: true, tags: ['pressure cooker', 'kitchen', 'cooking'] },
  { name: 'Philips Air Fryer HD9200', description: '4.1L capacity, Rapid Air technology, 90% less fat, dishwasher safe', price: 7999, originalPrice: 10999, discount: 27, category: 'Kitchen', brand: 'Philips', images: ['https://picsum.photos/seed/kitchen2/400/400'], stock: 100, rating: 4.5, numReviews: 2341, isBestseller: true, tags: ['air fryer', 'healthy cooking'] },
  { name: 'Prestige Induction Cooktop', description: '1600W, auto-switch off, 7 preset cooking options, feather touch controls', price: 2499, originalPrice: 3499, discount: 29, category: 'Kitchen', brand: 'Prestige', images: ['https://picsum.photos/seed/kitchen3/400/400'], stock: 200, rating: 4.3, numReviews: 1876, tags: ['induction', 'cooktop', 'cooking'] },
  { name: 'Bosch Hand Blender MSM2610B', description: '600W, ErgoMixx comfort grip, stainless steel blending shaft', price: 3499, originalPrice: 4999, discount: 30, category: 'Kitchen', brand: 'Bosch', images: ['https://picsum.photos/seed/kitchen4/400/400'], stock: 120, rating: 4.4, numReviews: 987, tags: ['blender', 'mixer', 'kitchen'] },
  { name: 'Milton Thermosteel Bottle 1L', description: 'Double wall insulation, keeps hot 24hr / cold 48hr, no sweat on outside', price: 599, originalPrice: 899, discount: 33, category: 'Kitchen', brand: 'Milton', images: ['https://picsum.photos/seed/kitchen5/400/400'], stock: 500, rating: 4.6, numReviews: 6782, isBestseller: true, tags: ['bottle', 'thermos', 'insulated'] },

  // Sports
  { name: 'Yonex Badminton Racket Astrox', description: 'ASTROX 88D Pro, high modulus graphite, 83g weight, for advanced players', price: 8999, originalPrice: 11999, discount: 25, category: 'Sports', brand: 'Yonex', images: ['https://picsum.photos/seed/sports1/400/400'], stock: 60, rating: 4.7, numReviews: 432, tags: ['badminton', 'racket', 'sports'] },
  { name: 'Decathlon Kiprun Running Shoes', description: 'Lightweight, cushioned midsole, breathable mesh, for road running', price: 3999, originalPrice: 5499, discount: 27, category: 'Sports', brand: 'Decathlon', images: ['https://picsum.photos/seed/sports2/400/400'], stock: 150, rating: 4.4, numReviews: 1234, isBestseller: true, tags: ['running', 'shoes', 'sports'] },
  { name: 'Boldfit Gym Bag 40L', description: 'Waterproof, separate shoe compartment, laptop sleeve, adjustable straps', price: 999, originalPrice: 1999, discount: 50, category: 'Sports', brand: 'Boldfit', images: ['https://picsum.photos/seed/sports3/400/400'], stock: 300, rating: 4.2, numReviews: 3456, tags: ['gym bag', 'fitness', 'sports'] },
  { name: 'Nivia Carbonite Basketball', description: 'Size 7, butyl inner tube, nylon wound, ideal for outdoor courts', price: 799, originalPrice: 1299, discount: 38, category: 'Sports', brand: 'Nivia', images: ['https://picsum.photos/seed/sports4/400/400'], stock: 200, rating: 4.3, numReviews: 876, tags: ['basketball', 'sports', 'outdoor'] },
  { name: 'Fitbit Charge 5 Fitness Tracker', description: 'Built-in GPS, heart rate monitoring, stress management, 7-day battery', price: 14999, originalPrice: 19999, discount: 25, category: 'Sports', brand: 'Fitbit', images: ['https://picsum.photos/seed/sports5/400/400'], stock: 80, rating: 4.5, numReviews: 2134, isFeatured: true, isNew: true, tags: ['fitness tracker', 'smartwatch', 'health'] },

  // Beauty
  { name: 'Lakme 9to5 Primer + Matte Lipstick', description: 'Long-stay formula, weightless finish, 16hr stay, vitamin E enriched', price: 299, originalPrice: 499, discount: 40, category: 'Beauty', brand: 'Lakme', images: ['https://picsum.photos/seed/beauty1/400/400'], stock: 400, rating: 4.3, numReviews: 5432, isBestseller: true, tags: ['lipstick', 'makeup', 'beauty'] },
  { name: 'Neutrogena Hydro Boost Moisturizer', description: 'Water gel with hyaluronic acid, oil-free, non-comedogenic, fragrance-free', price: 799, originalPrice: 1099, discount: 27, category: 'Beauty', brand: 'Neutrogena', images: ['https://picsum.photos/seed/beauty2/400/400'], stock: 250, rating: 4.6, numReviews: 8901, isBestseller: true, isFeatured: true, tags: ['moisturizer', 'skincare', 'hydration'] },
  { name: 'L\'Oreal Paris Serum Foundation', description: '24hr hydration, SPF 25, natural finish, 30ml, all skin types', price: 649, originalPrice: 899, discount: 28, category: 'Beauty', brand: 'L\'Oreal', images: ['https://picsum.photos/seed/beauty3/400/400'], stock: 180, rating: 4.2, numReviews: 3210, tags: ['foundation', 'makeup', 'SPF'] },
  { name: 'The Ordinary Niacinamide 10%', description: 'Reduces blemishes and congestion, balances sebum activity, brightens skin', price: 599, originalPrice: 799, discount: 25, category: 'Beauty', brand: 'The Ordinary', images: ['https://picsum.photos/seed/beauty4/400/400'], stock: 300, rating: 4.7, numReviews: 12456, isBestseller: true, isNew: false, tags: ['serum', 'niacinamide', 'skincare'] },
  { name: 'Biotique Bio Coconut Whitening Face Wash', description: '100% botanical extracts, removes impurities, brightens complexion, 150ml', price: 149, originalPrice: 249, discount: 40, category: 'Beauty', brand: 'Biotique', images: ['https://picsum.photos/seed/beauty5/400/400'], stock: 600, rating: 4.1, numReviews: 7654, tags: ['face wash', 'skincare', 'natural'] },
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/amazon-clone');
    console.log('Connected to MongoDB');

    await Product.deleteMany({});
    console.log('Cleared products');

    const createdProducts = await Product.insertMany(products);
    console.log(`✅ ${createdProducts.length} products seeded`);

    // Create admin user
    await User.deleteMany({ email: 'admin@amazon-clone.com' });
    await User.create({ name: 'Admin User', email: 'admin@amazon-clone.com', password: 'admin123', role: 'admin' });
    console.log('✅ Admin user created: admin@amazon-clone.com / admin123');

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

seed();
