/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        amazon: {
          DEFAULT: '#131921',
          light: '#232F3E',
          yellow: '#FF9900',
          'yellow-hover': '#f0a500',
          blue: '#007185',
          'blue-hover': '#005f6b',
          orange: '#FF9900',
          red: '#B12704',
          green: '#007600',
          gray: '#555',
        },
      },
      fontFamily: {
        amazon: ['"Amazon Ember"', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
