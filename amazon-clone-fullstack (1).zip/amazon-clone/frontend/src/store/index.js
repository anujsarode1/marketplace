'use client';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import axios from 'axios';
import toast from 'react-hot-toast';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

// ── AUTH STORE ──────────────────────────────────────
export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      loading: false,

      login: async (email, password) => {
        set({ loading: true });
        try {
          const { data } = await axios.post(`${API}/auth/login`, { email, password });
          set({ user: data.user, token: data.token, loading: false });
          toast.success(`Welcome back, ${data.user.name}!`);
          return { success: true };
        } catch (err) {
          set({ loading: false });
          const msg = err.response?.data?.message || 'Login failed';
          toast.error(msg);
          return { success: false, message: msg };
        }
      },

      register: async (name, email, password) => {
        set({ loading: true });
        try {
          const { data } = await axios.post(`${API}/auth/register`, { name, email, password });
          set({ user: data.user, token: data.token, loading: false });
          toast.success('Account created successfully!');
          return { success: true };
        } catch (err) {
          set({ loading: false });
          const msg = err.response?.data?.message || 'Registration failed';
          toast.error(msg);
          return { success: false, message: msg };
        }
      },

      logout: () => {
        set({ user: null, token: null });
        useCartStore.getState().clearCart();
        toast.success('Logged out successfully');
      },

      updateProfile: async (data) => {
        try {
          const token = get().token;
          const res = await axios.put(`${API}/auth/profile`, data, {
            headers: { Authorization: `Bearer ${token}` },
          });
          set({ user: res.data.user });
          toast.success('Profile updated!');
          return { success: true };
        } catch (err) {
          toast.error(err.response?.data?.message || 'Update failed');
          return { success: false };
        }
      },
    }),
    { name: 'auth-store', storage: createJSONStorage(() => localStorage) }
  )
);

// ── CART STORE ──────────────────────────────────────
export const useCartStore = create(
  persist(
    (set, get) => ({
      items: [], // [{product, qty}]
      savedForLater: [],

      addToCart: (product, qty = 1) => {
        const items = get().items;
        const existing = items.find(i => i.product._id === product._id);
        if (existing) {
          set({ items: items.map(i => i.product._id === product._id ? { ...i, qty: i.qty + qty } : i) });
        } else {
          set({ items: [...items, { product, qty }] });
        }
        toast.success('Added to cart!');
      },

      removeFromCart: (productId) => {
        set({ items: get().items.filter(i => i.product._id !== productId) });
        toast.success('Removed from cart');
      },

      updateQty: (productId, qty) => {
        if (qty < 1) return get().removeFromCart(productId);
        set({ items: get().items.map(i => i.product._id === productId ? { ...i, qty } : i) });
      },

      saveForLater: (productId) => {
        const items = get().items;
        const item = items.find(i => i.product._id === productId);
        if (item) {
          set({
            items: items.filter(i => i.product._id !== productId),
            savedForLater: [...get().savedForLater, item],
          });
          toast.success('Saved for later');
        }
      },

      moveToCart: (productId) => {
        const saved = get().savedForLater;
        const item = saved.find(i => i.product._id === productId);
        if (item) {
          set({
            savedForLater: saved.filter(i => i.product._id !== productId),
            items: [...get().items, item],
          });
          toast.success('Moved to cart');
        }
      },

      clearCart: () => set({ items: [], savedForLater: [] }),

      get total() {
        return get().items.reduce((sum, i) => sum + i.product.price * i.qty, 0);
      },

      get itemCount() {
        return get().items.reduce((sum, i) => sum + i.qty, 0);
      },
    }),
    { name: 'cart-store', storage: createJSONStorage(() => localStorage) }
  )
);

// ── WISHLIST STORE ──────────────────────────────────
export const useWishlistStore = create(
  persist(
    (set, get) => ({
      items: [],

      toggle: async (product) => {
        const token = useAuthStore.getState().token;
        const items = get().items;
        const exists = items.find(i => i._id === product._id);

        if (exists) {
          set({ items: items.filter(i => i._id !== product._id) });
          toast.success('Removed from wishlist');
        } else {
          set({ items: [...items, product] });
          toast.success('Added to wishlist!');
        }

        // Sync with backend if logged in
        if (token) {
          try {
            await axios.post(`${API}/users/wishlist/${product._id}`, {}, {
              headers: { Authorization: `Bearer ${token}` },
            });
          } catch {}
        }
      },

      isWishlisted: (productId) => get().items.some(i => i._id === productId),

      clearWishlist: () => set({ items: [] }),
    }),
    { name: 'wishlist-store', storage: createJSONStorage(() => localStorage) }
  )
);

// ── RECENTLY VIEWED STORE ───────────────────────────
export const useRecentlyViewedStore = create(
  persist(
    (set, get) => ({
      products: [],
      add: (product) => {
        const existing = get().products.filter(p => p._id !== product._id);
        set({ products: [product, ...existing].slice(0, 10) });
      },
    }),
    { name: 'recently-viewed', storage: createJSONStorage(() => localStorage) }
  )
);

// ── API HELPER ──────────────────────────────────────
export const apiClient = () => {
  const token = useAuthStore.getState().token;
  return axios.create({
    baseURL: API,
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
};
