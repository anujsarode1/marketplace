'use client';
import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import axios from 'axios';
import ProductCard from '@/components/product/ProductCard';
import { useRecentlyViewedStore } from '@/store';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

const HERO_SLIDES = [
  { bg: 'from-blue-900 to-blue-700', title: 'Electronics Sale', sub: 'Up to 40% off on top brands', link: '/search?category=Electronics', emoji: '📱', label: 'Shop Electronics' },
  { bg: 'from-orange-600 to-yellow-500', title: "Today's Best Deals", sub: 'Limited time offers on top products', link: '/search?featured=true', emoji: '🔥', label: 'See All Deals' },
  { bg: 'from-green-800 to-green-600', title: 'Kitchen & Home', sub: 'Make your home smarter', link: '/search?category=Kitchen', emoji: '🍳', label: 'Shop Kitchen' },
  { bg: 'from-purple-800 to-pink-600', title: 'Beauty & Personal Care', sub: 'Glow up with the best brands', link: '/search?category=Beauty', emoji: '✨', label: 'Shop Beauty' },
];

const CATEGORIES = [
  { name: 'Electronics', emoji: '📱', color: 'bg-blue-50' },
  { name: 'Clothing', emoji: '👕', color: 'bg-pink-50' },
  { name: 'Books', emoji: '📚', color: 'bg-yellow-50' },
  { name: 'Kitchen', emoji: '🍳', color: 'bg-orange-50' },
  { name: 'Sports', emoji: '⚽', color: 'bg-green-50' },
  { name: 'Beauty', emoji: '💄', color: 'bg-purple-50' },
];

export default function HomePage() {
  const [slide, setSlide] = useState(0);
  const [featured, setFeatured] = useState([]);
  const [bestsellers, setBestsellers] = useState([]);
  const [newArrivals, setNewArrivals] = useState([]);
  const [loading, setLoading] = useState(true);
  const { products: recentlyViewed } = useRecentlyViewedStore();

  const nextSlide = useCallback(() => setSlide(s => (s + 1) % HERO_SLIDES.length), []);
  const prevSlide = () => setSlide(s => (s - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);

  useEffect(() => {
    const timer = setInterval(nextSlide, 4000);
    return () => clearInterval(timer);
  }, [nextSlide]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const [f, b, n] = await Promise.all([
          axios.get(`${API}/products?featured=true&limit=8`),
          axios.get(`${API}/products?bestseller=true&limit=8`),
          axios.get(`${API}/products?sort=newest&limit=8`),
        ]);
        setFeatured(f.data.products || []);
        setBestsellers(b.data.products || []);
        setNewArrivals(n.data.products || []);
      } catch (err) {
        console.error('Failed to fetch products', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const current = HERO_SLIDES[slide];

  return (
    <div className="bg-gray-100 pb-8">
      {/* Hero Carousel */}
      <div className={`relative bg-gradient-to-r ${current.bg} text-white overflow-hidden`} style={{ minHeight: 320 }}>
        <div className="max-w-7xl mx-auto px-6 py-16 flex items-center justify-between">
          <div className="max-w-lg">
            <h1 className="text-4xl font-bold mb-3">{current.title}</h1>
            <p className="text-lg opacity-90 mb-6">{current.sub}</p>
            <Link href={current.link} className="inline-block bg-amazon-yellow text-black font-bold px-6 py-3 rounded hover:bg-amber-400 transition-colors">
              {current.label} →
            </Link>
          </div>
          <div className="text-9xl hidden md:block select-none">{current.emoji}</div>
        </div>

        {/* Arrow controls */}
        <button onClick={prevSlide} className="absolute left-3 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2">
          <FiChevronLeft size={24} />
        </button>
        <button onClick={nextSlide} className="absolute right-3 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2">
          <FiChevronRight size={24} />
        </button>

        {/* Dots */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
          {HERO_SLIDES.map((_, i) => (
            <button key={i} onClick={() => setSlide(i)}
              className={`w-2 h-2 rounded-full transition-colors ${i === slide ? 'bg-white' : 'bg-white/40'}`}
            />
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-6 space-y-8">
        {/* Categories */}
        <section>
          <h2 className="text-xl font-bold text-gray-800 mb-4">Shop by Category</h2>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {CATEGORIES.map(cat => (
              <Link key={cat.name} href={`/search?category=${cat.name}`}
                className={`${cat.color} rounded-lg p-4 text-center hover:shadow-md transition-shadow group`}>
                <div className="text-4xl mb-2 group-hover:scale-110 transition-transform">{cat.emoji}</div>
                <div className="text-xs font-semibold text-gray-700">{cat.name}</div>
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Products */}
        <Section title="Featured Products" link="/search?featured=true" products={featured} loading={loading} />

        {/* Bestsellers */}
        <Section title="🔥 Bestsellers" link="/search?bestseller=true" products={bestsellers} loading={loading} />

        {/* New Arrivals */}
        <Section title="✨ New Arrivals" link="/search?sort=newest" products={newArrivals} loading={loading} />

        {/* Recently Viewed */}
        {recentlyViewed.length > 0 && (
          <Section title="Recently Viewed" link="#" products={recentlyViewed.slice(0, 8)} loading={false} />
        )}

        {/* Promo banners */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Link href="/search?category=Books" className="bg-gradient-to-r from-amber-100 to-yellow-200 rounded-lg p-6 flex items-center justify-between hover:shadow-md transition-shadow">
            <div>
              <h3 className="font-bold text-lg text-amber-900">Books up to 40% off</h3>
              <p className="text-amber-700 text-sm mt-1">Bestsellers, self-help, fiction & more</p>
              <span className="mt-3 inline-block text-amazon-blue text-sm font-semibold hover:underline">Shop now →</span>
            </div>
            <span className="text-7xl">📚</span>
          </Link>
          <Link href="/search?category=Sports" className="bg-gradient-to-r from-green-100 to-emerald-200 rounded-lg p-6 flex items-center justify-between hover:shadow-md transition-shadow">
            <div>
              <h3 className="font-bold text-lg text-green-900">Sports & Fitness</h3>
              <p className="text-green-700 text-sm mt-1">Equipment, apparel & accessories</p>
              <span className="mt-3 inline-block text-amazon-blue text-sm font-semibold hover:underline">Shop now →</span>
            </div>
            <span className="text-7xl">🏃</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

function Section({ title, link, products, loading }) {
  if (loading) return (
    <section>
      <div className="flex items-center justify-between mb-4">
        <div className="h-6 bg-gray-200 rounded w-40 animate-pulse" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-white rounded shadow-sm animate-pulse h-72" />
        ))}
      </div>
    </section>
  );

  if (!products?.length) return null;

  return (
    <section>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-800">{title}</h2>
        <Link href={link} className="text-amazon-blue text-sm hover:underline">See all →</Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.slice(0, 8).map(p => <ProductCard key={p._id} product={p} />)}
      </div>
    </section>
  );
}
