'use client';
import { useWishlistStore, useCartStore } from '@/store';
import Link from 'next/link';
import { AiFillHeart } from 'react-icons/ai';
import { FiShoppingCart } from 'react-icons/fi';

export default function WishlistPage() {
  const { items, toggle } = useWishlistStore();
  const { addToCart } = useCartStore();

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <AiFillHeart size={80} className="mx-auto text-gray-200 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Your Wishlist is empty</h2>
        <p className="text-gray-500 mb-6">Save items you love for later</p>
        <Link href="/" className="btn-primary inline-block">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">My Wishlist ({items.length})</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {items.map(product => (
          <div key={product._id} className="bg-white rounded shadow-sm overflow-hidden group">
            <div className="relative">
              <Link href={`/product/${product._id}`}>
                <div className="h-48 bg-gray-50 flex items-center justify-center">
                  <img
                    src={product.images?.[0] || `https://picsum.photos/seed/${product._id}/300/300`}
                    alt={product.name}
                    className="max-h-full max-w-full object-contain p-3"
                  />
                </div>
              </Link>
              <button
                onClick={() => toggle(product)}
                className="absolute top-2 right-2 bg-white rounded-full p-1.5 shadow"
              >
                <AiFillHeart className="text-red-500" size={18} />
              </button>
            </div>
            <div className="p-3">
              <Link href={`/product/${product._id}`}>
                <h3 className="text-sm font-medium line-clamp-2 hover:text-amazon-blue mb-1">{product.name}</h3>
              </Link>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="font-bold text-lg">₹{product.price?.toLocaleString()}</span>
                {product.originalPrice > product.price && (
                  <span className="text-sm text-gray-400 line-through">₹{product.originalPrice?.toLocaleString()}</span>
                )}
              </div>
              <button
                onClick={() => { addToCart(product); toggle(product); }}
                className="btn-primary w-full text-xs flex items-center justify-center gap-2"
              >
                <FiShoppingCart size={14} /> Move to Cart
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
