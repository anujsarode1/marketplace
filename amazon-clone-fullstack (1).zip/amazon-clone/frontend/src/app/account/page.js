'use client';
import { useState, useEffect } from 'react';
import { useAuthStore, apiClient } from '@/store';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { FiUser, FiPackage, FiHeart, FiMapPin, FiLogOut, FiEdit } from 'react-icons/fi';

export default function AccountPage() {
  const { user, updateProfile, logout } = useAuthStore();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('profile');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [addresses, setAddresses] = useState([]);
  const [addingAddress, setAddingAddress] = useState(false);
  const [addrForm, setAddrForm] = useState({ name: '', phone: '', street: '', city: '', state: '', pincode: '', isDefault: false });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) { router.push('/auth/login?redirect=/account'); return; }
    setForm({ name: user.name, email: user.email, password: '' });
    fetchAddresses();
  }, [user]);

  const fetchAddresses = async () => {
    try {
      const client = apiClient();
      const { data } = await client.get('/users/addresses');
      setAddresses(data.addresses);
    } catch { }
  };

  const handleProfileSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    await updateProfile({ name: form.name, email: form.email, ...(form.password && { password: form.password }) });
    setSaving(false);
  };

  const handleAddAddress = async (e) => {
    e.preventDefault();
    try {
      const client = apiClient();
      const { data } = await client.post('/users/addresses', addrForm);
      setAddresses(data.addresses);
      setAddingAddress(false);
      setAddrForm({ name: '', phone: '', street: '', city: '', state: '', pincode: '', isDefault: false });
      toast.success('Address added!');
    } catch { toast.error('Failed to add address'); }
  };

  const handleDeleteAddress = async (addressId) => {
    try {
      const client = apiClient();
      const { data } = await client.delete(`/users/addresses/${addressId}`);
      setAddresses(data.addresses);
      toast.success('Address removed');
    } catch { }
  };

  if (!user) return null;

  const TABS = [
    { id: 'profile', label: 'Profile', icon: FiUser },
    { id: 'addresses', label: 'Addresses', icon: FiMapPin },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Your Account</h1>

      {/* Quick links */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Your Orders', icon: FiPackage, href: '/orders', desc: 'Track, return or buy again' },
          { label: 'Wishlist', icon: FiHeart, href: '/wishlist', desc: 'Your saved items' },
          { label: 'Addresses', icon: FiMapPin, href: '#', desc: 'Edit delivery addresses', onClick: () => setActiveTab('addresses') },
          { label: 'Profile', icon: FiUser, href: '#', desc: 'Update your details', onClick: () => setActiveTab('profile') },
        ].map(item => (
          <Link
            key={item.label}
            href={item.href}
            onClick={item.onClick}
            className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <item.icon size={24} className="text-amazon-blue mb-2" />
            <div className="font-medium text-sm">{item.label}</div>
            <div className="text-xs text-gray-500 mt-0.5">{item.desc}</div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="md:col-span-1">
          <div className="bg-white rounded shadow-sm p-4">
            <div className="flex items-center gap-3 mb-4 pb-4 border-b">
              <div className="w-12 h-12 rounded-full bg-amazon text-white flex items-center justify-center text-xl font-bold">
                {user.name?.[0]?.toUpperCase()}
              </div>
              <div>
                <p className="font-medium text-sm">{user.name}</p>
                <p className="text-xs text-gray-500">{user.email}</p>
              </div>
            </div>
            {TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded text-sm mb-1 transition-colors
                  ${activeTab === tab.id ? 'bg-amazon text-white' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <tab.icon size={16} /> {tab.label}
              </button>
            ))}
            <button
              onClick={() => { logout(); router.push('/'); }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded text-sm text-red-600 hover:bg-red-50 mt-2"
            >
              <FiLogOut size={16} /> Sign Out
            </button>
          </div>
        </div>

        {/* Main content */}
        <div className="md:col-span-3">
          {activeTab === 'profile' && (
            <div className="bg-white rounded shadow-sm p-6">
              <h2 className="text-lg font-bold mb-4 flex items-center gap-2"><FiEdit size={18} /> Edit Profile</h2>
              <form onSubmit={handleProfileSave} className="space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium mb-1">Full Name</label>
                  <input type="text" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="input-field" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Email Address</label>
                  <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className="input-field" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">New Password <span className="text-gray-400 font-normal">(leave blank to keep current)</span></label>
                  <input type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} className="input-field" placeholder="Min 6 characters" />
                </div>
                <button type="submit" disabled={saving} className="btn-primary disabled:opacity-50">
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </form>
            </div>
          )}

          {activeTab === 'addresses' && (
            <div className="bg-white rounded shadow-sm p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold">Your Addresses</h2>
                <button onClick={() => setAddingAddress(!addingAddress)} className="btn-primary text-xs py-1.5">
                  + Add New Address
                </button>
              </div>

              {addingAddress && (
                <form onSubmit={handleAddAddress} className="border border-gray-200 rounded p-4 mb-4 bg-gray-50">
                  <h3 className="font-medium mb-3">New Address</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { key: 'name', label: 'Full Name', span: true },
                      { key: 'phone', label: 'Phone', span: true },
                      { key: 'street', label: 'Street', span: true },
                      { key: 'city', label: 'City' },
                      { key: 'state', label: 'State' },
                      { key: 'pincode', label: 'PIN Code' },
                    ].map(f => (
                      <div key={f.key} className={f.span ? 'col-span-2' : ''}>
                        <label className="block text-xs font-medium mb-1">{f.label}</label>
                        <input type="text" value={addrForm[f.key]} onChange={e => setAddrForm(a => ({ ...a, [f.key]: e.target.value }))} required className="input-field text-sm" />
                      </div>
                    ))}
                    <div className="col-span-2">
                      <label className="flex items-center gap-2 text-sm cursor-pointer">
                        <input type="checkbox" checked={addrForm.isDefault} onChange={e => setAddrForm(a => ({ ...a, isDefault: e.target.checked }))} />
                        Set as default address
                      </label>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button type="submit" className="btn-primary text-sm">Save Address</button>
                    <button type="button" onClick={() => setAddingAddress(false)} className="btn-secondary text-sm">Cancel</button>
                  </div>
                </form>
              )}

              {addresses.length === 0 ? (
                <p className="text-gray-500 text-sm">No addresses saved yet.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {addresses.map(addr => (
                    <div key={addr._id} className={`border rounded-lg p-4 relative ${addr.isDefault ? 'border-amazon-yellow bg-yellow-50' : 'border-gray-200'}`}>
                      {addr.isDefault && <span className="badge bg-amazon-yellow text-black text-xs absolute top-2 right-2">Default</span>}
                      <p className="font-medium text-sm">{addr.name}</p>
                      <p className="text-sm text-gray-700 mt-1">{addr.street}</p>
                      <p className="text-sm text-gray-700">{addr.city}, {addr.state} – {addr.pincode}</p>
                      <p className="text-sm text-gray-700">📞 {addr.phone}</p>
                      <button onClick={() => handleDeleteAddress(addr._id)} className="text-amazon-blue text-xs hover:underline mt-2">Remove</button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
