'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCartStore, useAuthStore, apiClient } from '@/store';
import toast from 'react-hot-toast';
import Link from 'next/link';
import { FiCheck } from 'react-icons/fi';

const STEPS = ['Address', 'Payment', 'Review'];

export default function CheckoutPage() {
  const router = useRouter();
  const { items, clearCart } = useCartStore();
  const { user } = useAuthStore();
  const [step, setStep] = useState(0);
  const [placing, setPlacing] = useState(false);

  const [address, setAddress] = useState({
    name: user?.name || '',
    phone: '',
    street: '',
    city: '',
    state: '',
    pincode: '',
  });
  const [payment, setPayment] = useState('COD');
  const [errors, setErrors] = useState({});

  const subtotal = items.reduce((s, i) => s + i.product.price * i.qty, 0);
  const shipping = subtotal >= 499 ? 0 : 40;
  const tax = Math.round(subtotal * 0.18);
  const total = subtotal + shipping + tax;

  const validateAddress = () => {
    const e = {};
    if (!address.name.trim()) e.name = 'Name is required';
    if (!address.phone.match(/^\d{10}$/)) e.phone = 'Enter valid 10-digit phone';
    if (!address.street.trim()) e.street = 'Street is required';
    if (!address.city.trim()) e.city = 'City is required';
    if (!address.state.trim()) e.state = 'State is required';
    if (!address.pincode.match(/^\d{6}$/)) e.pincode = 'Enter valid 6-digit pincode';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleNext = () => {
    if (step === 0 && !validateAddress()) return;
    setStep(s => s + 1);
  };

  const placeOrder = async () => {
    setPlacing(true);
    try {
      const client = apiClient();
      const orderItems = items.map(i => ({
        product: i.product._id,
        name: i.product.name,
        image: i.product.images?.[0] || '',
        price: i.product.price,
        qty: i.qty,
      }));

      const { data } = await client.post('/orders', {
        orderItems,
        shippingAddress: address,
        paymentMethod: payment,
        itemsPrice: subtotal,
        shippingPrice: shipping,
        taxPrice: tax,
        totalPrice: total,
      });

      clearCart();
      toast.success('Order placed successfully!');
      router.push(`/orders/${data.order._id}?success=1`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to place order');
    } finally {
      setPlacing(false);
    }
  };

  if (!user) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-bold mb-4">Please sign in to checkout</h2>
        <Link href="/auth/login?redirect=/checkout" className="btn-primary inline-block">Sign In</Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-bold mb-4">Your cart is empty</h2>
        <Link href="/" className="btn-primary inline-block">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      {/* Step indicator */}
      <div className="flex items-center justify-center mb-8">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center">
            <div className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold
              ${i < step ? 'bg-amazon-yellow text-black' : i === step ? 'bg-amazon text-white' : 'bg-gray-200 text-gray-500'}`}>
              {i < step ? <FiCheck size={14} /> : i + 1}
            </div>
            <span className={`ml-2 text-sm font-medium ${i === step ? 'text-gray-900' : 'text-gray-400'}`}>{s}</span>
            {i < STEPS.length - 1 && <div className={`w-16 h-0.5 mx-3 ${i < step ? 'bg-amazon-yellow' : 'bg-gray-200'}`} />}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main form */}
        <div className="lg:col-span-2">

          {/* Step 0: Address */}
          {step === 0 && (
            <div className="bg-white rounded shadow-sm p-6">
              <h2 className="text-lg font-bold mb-4">Delivery Address</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { key: 'name', label: 'Full Name', placeholder: 'John Doe', colSpan: true },
                  { key: 'phone', label: 'Phone Number', placeholder: '10-digit mobile number', colSpan: true },
                  { key: 'street', label: 'Street / House No.', placeholder: '123 Main Street, Apt 4B', colSpan: true },
                  { key: 'city', label: 'City', placeholder: 'Mumbai' },
                  { key: 'state', label: 'State', placeholder: 'Maharashtra' },
                  { key: 'pincode', label: 'PIN Code', placeholder: '400001' },
                ].map(field => (
                  <div key={field.key} className={field.colSpan ? 'md:col-span-2' : ''}>
                    <label className="block text-sm font-medium mb-1">{field.label}</label>
                    <input
                      type="text"
                      value={address[field.key]}
                      onChange={e => setAddress(a => ({ ...a, [field.key]: e.target.value }))}
                      placeholder={field.placeholder}
                      className={`input-field ${errors[field.key] ? 'border-red-500 ring-1 ring-red-400' : ''}`}
                    />
                    {errors[field.key] && <p className="text-red-500 text-xs mt-1">{errors[field.key]}</p>}
                  </div>
                ))}
              </div>
              <button onClick={handleNext} className="btn-primary mt-6 px-8">Use this address</button>
            </div>
          )}

          {/* Step 1: Payment */}
          {step === 1 && (
            <div className="bg-white rounded shadow-sm p-6">
              <h2 className="text-lg font-bold mb-4">Payment Method</h2>
              <div className="space-y-3">
                {[
                  { id: 'COD', label: 'Cash on Delivery', icon: '💵', desc: 'Pay when your order arrives' },
                  { id: 'Card', label: 'Credit / Debit Card', icon: '💳', desc: 'All major cards accepted' },
                  { id: 'UPI', label: 'UPI Payment', icon: '📱', desc: 'PhonePe, GPay, Paytm & more' },
                ].map(m => (
                  <label key={m.id} className={`flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer transition-colors
                    ${payment === m.id ? 'border-amazon-yellow bg-yellow-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <input type="radio" name="payment" value={m.id} checked={payment === m.id} onChange={() => setPayment(m.id)} className="w-4 h-4 accent-amazon-yellow" />
                    <span className="text-2xl">{m.icon}</span>
                    <div>
                      <div className="font-medium">{m.label}</div>
                      <div className="text-xs text-gray-500">{m.desc}</div>
                    </div>
                  </label>
                ))}
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(0)} className="btn-secondary px-6">Back</button>
                <button onClick={handleNext} className="btn-primary px-8">Continue</button>
              </div>
            </div>
          )}

          {/* Step 2: Review */}
          {step === 2 && (
            <div className="bg-white rounded shadow-sm p-6">
              <h2 className="text-lg font-bold mb-4">Review Your Order</h2>

              <div className="space-y-3 mb-4">
                {items.map(({ product, qty }) => (
                  <div key={product._id} className="flex gap-3 py-2 border-b last:border-0">
                    <img src={product.images?.[0] || `https://picsum.photos/seed/${product._id}/80/80`} alt="" className="w-16 h-16 object-contain border rounded bg-gray-50" />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{product.name}</p>
                      <p className="text-xs text-gray-500">Qty: {qty}</p>
                    </div>
                    <p className="font-bold">₹{(product.price * qty).toLocaleString()}</p>
                  </div>
                ))}
              </div>

              <div className="bg-gray-50 rounded p-4 mb-4 text-sm space-y-1">
                <p className="font-medium mb-2">Delivery Address</p>
                <p>{address.name}</p>
                <p>{address.street}, {address.city}</p>
                <p>{address.state} – {address.pincode}</p>
                <p>📞 {address.phone}</p>
              </div>

              <div className="bg-gray-50 rounded p-4 mb-4 text-sm">
                <p className="font-medium mb-1">Payment Method</p>
                <p>{payment === 'COD' ? '💵 Cash on Delivery' : payment === 'Card' ? '💳 Credit/Debit Card' : '📱 UPI'}</p>
              </div>

              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="btn-secondary px-6">Back</button>
                <button onClick={placeOrder} disabled={placing} className="btn-orange px-8 disabled:opacity-50">
                  {placing ? 'Placing Order...' : 'Place Order'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Price summary sidebar */}
        <div>
          <div className="bg-white rounded shadow-sm p-4 sticky top-20">
            <h3 className="font-bold border-b pb-2 mb-3">Order Summary</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Items ({items.reduce((s,i)=>s+i.qty,0)}):</span>
                <span>₹{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping:</span>
                <span className={shipping===0?'text-green-600':''}>{shipping===0?'FREE':`₹${shipping}`}</span>
              </div>
              <div className="flex justify-between">
                <span>GST (18%):</span>
                <span>₹{tax.toLocaleString()}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold text-base">
                <span>Order Total:</span>
                <span className="text-red-600">₹{total.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
