'use client';
import { useCartStore, useAuthStore } from '@/store';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FiTrash2, FiShoppingBag } from 'react-icons/fi';

export default function CartPage() {
  const router = useRouter();
  const { items, savedForLater, removeFromCart, updateQty, saveForLater, moveToCart } = useCartStore();
  const { user } = useAuthStore();

  const subtotal = items.reduce((s, i) => s + i.product.price * i.qty, 0);
  const itemCount = items.reduce((s, i) => s + i.qty, 0);
  const shipping = subtotal >= 499 ? 0 : 40;
  const tax = Math.round(subtotal * 0.18);
  const total = subtotal + shipping + tax;

  const handleCheckout = () => {
    if (!user) { router.push('/auth/login?redirect=/checkout'); return; }
    router.push('/checkout');
  };

  if (items.length === 0 && savedForLater.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <FiShoppingBag size={80} className="mx-auto text-gray-300 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Your Amazon Cart is empty</h2>
        <p className="text-gray-500 mb-6">Shop today's deals</p>
        <Link href="/" className="btn-primary inline-block">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded shadow-sm p-4">
            <h1 className="text-2xl font-bold border-b pb-3 mb-4">Shopping Cart</h1>

            {items.length === 0 && (
              <p className="text-gray-500 text-center py-8">No items in cart</p>
            )}

            {items.map(({ product, qty }) => (
              <div key={product._id} className="flex gap-4 border-b py-4 last:border-0">
                <Link href={`/product/${product._id}`}>
                  <img
                    src={product.images?.[0] || `https://picsum.photos/seed/${product._id}/200/200`}
                    alt={product.name}
                    className="w-28 h-28 object-contain border rounded bg-gray-50"
                  />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link href={`/product/${product._id}`}>
                    <h3 className="font-medium text-sm hover:text-amazon-blue line-clamp-2">{product.name}</h3>
                  </Link>
                  {product.stock > 0
                    ? <p className="text-amazon-green text-xs mt-1">In Stock</p>
                    : <p className="text-red-600 text-xs mt-1">Out of Stock</p>}
                  <p className="text-xs text-gray-500 mt-1">Sold by: {product.brand || 'Amazon Seller'}</p>

                  {/* Qty + Actions */}
                  <div className="flex items-center gap-3 mt-3 flex-wrap">
                    <div className="flex items-center border border-gray-300 rounded overflow-hidden">
                      <button onClick={() => updateQty(product._id, qty - 1)} className="px-3 py-1 hover:bg-gray-100 font-bold">−</button>
                      <span className="px-3 py-1 border-x border-gray-300 text-sm">{qty}</span>
                      <button onClick={() => updateQty(product._id, qty + 1)} className="px-3 py-1 hover:bg-gray-100 font-bold">+</button>
                    </div>
                    <span className="text-gray-300">|</span>
                    <button onClick={() => removeFromCart(product._id)} className="text-amazon-blue text-xs hover:underline flex items-center gap-1">
                      <FiTrash2 size={12} /> Delete
                    </button>
                    <span className="text-gray-300">|</span>
                    <button onClick={() => saveForLater(product._id)} className="text-amazon-blue text-xs hover:underline">Save for later</button>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-lg">₹{(product.price * qty).toLocaleString()}</div>
                  {qty > 1 && <div className="text-xs text-gray-500">₹{product.price?.toLocaleString()} each</div>}
                </div>
              </div>
            ))}

            {items.length > 0 && (
              <div className="text-right pt-2">
                <span className="text-lg">
                  Subtotal ({itemCount} item{itemCount > 1 ? 's' : ''}): <span className="font-bold">₹{subtotal.toLocaleString()}</span>
                </span>
              </div>
            )}
          </div>

          {/* Saved for later */}
          {savedForLater.length > 0 && (
            <div className="bg-white rounded shadow-sm p-4">
              <h2 className="text-lg font-bold border-b pb-3 mb-4">Saved for Later ({savedForLater.length})</h2>
              {savedForLater.map(({ product, qty }) => (
                <div key={product._id} className="flex gap-4 border-b py-4 last:border-0">
                  <img src={product.images?.[0] || `https://picsum.photos/seed/${product._id}/100/100`} alt={product.name} className="w-20 h-20 object-contain border rounded bg-gray-50" />
                  <div className="flex-1">
                    <h3 className="text-sm font-medium">{product.name}</h3>
                    <p className="font-bold mt-1">₹{product.price?.toLocaleString()}</p>
                    <div className="flex gap-3 mt-2">
                      <button onClick={() => moveToCart(product._id)} className="btn-primary text-xs py-1">Move to Cart</button>
                      <button onClick={() => removeFromCart(product._id)} className="text-amazon-blue text-xs hover:underline">Delete</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Order Summary */}
        <div>
          <div className="bg-white rounded shadow-sm p-4 sticky top-20">
            <h2 className="font-bold text-lg mb-4 border-b pb-2">Order Summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Items ({itemCount}):</span>
                <span>₹{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery:</span>
                <span className={shipping === 0 ? 'text-amazon-green' : ''}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax (18% GST):</span>
                <span>₹{tax.toLocaleString()}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold text-base">
                <span>Order Total:</span>
                <span>₹{total.toLocaleString()}</span>
              </div>
            </div>

            {subtotal < 499 && (
              <p className="text-xs text-amazon-blue mt-3 bg-blue-50 p-2 rounded">
                Add ₹{(499 - subtotal).toLocaleString()} more for FREE delivery
              </p>
            )}

            <button
              onClick={handleCheckout}
              disabled={items.length === 0}
              className="btn-primary w-full mt-4 py-3 text-base font-bold disabled:opacity-50"
            >
              Proceed to Buy ({itemCount} item{itemCount > 1 ? 's' : ''})
            </button>

            <div className="mt-3 text-center">
              <div className="flex justify-center gap-2 text-xs text-gray-500">
                <span>🔒 Secure transaction</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
