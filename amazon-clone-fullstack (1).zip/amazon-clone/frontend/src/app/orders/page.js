'use client';
import { useState, useEffect } from 'react';
import { useAuthStore, apiClient } from '@/store';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { FiPackage, FiChevronRight } from 'react-icons/fi';

const STATUS_COLORS = {
  Confirmed: 'bg-blue-100 text-blue-700',
  Processing: 'bg-yellow-100 text-yellow-700',
  Shipped: 'bg-purple-100 text-purple-700',
  'Out for Delivery': 'bg-orange-100 text-orange-700',
  Delivered: 'bg-green-100 text-green-700',
  Cancelled: 'bg-red-100 text-red-700',
};

export default function OrdersPage() {
  const { user, token } = useAuthStore();
  const router = useRouter();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    if (!user) { router.push('/auth/login?redirect=/orders'); return; }
    fetchOrders();
  }, [user]);

  const fetchOrders = async () => {
    try {
      const client = apiClient();
      const { data } = await client.get('/orders/my');
      setOrders(data.orders);
    } catch { } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        {[1,2,3].map(i => (
          <div key={i} className="bg-white rounded shadow-sm p-4 mb-4 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/3 mb-2" />
            <div className="h-4 bg-gray-200 rounded w-1/4" />
          </div>
        ))}
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <FiPackage size={80} className="mx-auto text-gray-300 mb-4" />
        <h2 className="text-2xl font-bold mb-2">No orders yet</h2>
        <p className="text-gray-500 mb-6">Looks like you haven't placed any orders</p>
        <Link href="/" className="btn-primary inline-block">Start Shopping</Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Your Orders ({orders.length})</h1>
      <div className="space-y-4">
        {orders.map(order => (
          <div key={order._id} className="bg-white rounded shadow-sm overflow-hidden">
            {/* Order header */}
            <div className="bg-gray-50 border-b px-4 py-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap gap-6 text-sm">
                <div>
                  <p className="text-gray-500 text-xs uppercase tracking-wide">Order Placed</p>
                  <p className="font-medium">{new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-xs uppercase tracking-wide">Total</p>
                  <p className="font-medium">₹{order.totalPrice?.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-xs uppercase tracking-wide">Payment</p>
                  <p className="font-medium">{order.paymentMethod}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${STATUS_COLORS[order.status] || 'bg-gray-100'}`}>
                  {order.status}
                </span>
                <span className="text-xs text-gray-500">#{order._id.slice(-8).toUpperCase()}</span>
              </div>
            </div>

            {/* Order items preview */}
            <div className="p-4">
              {order.orderItems?.slice(0, expanded === order._id ? undefined : 2).map((item, i) => (
                <div key={i} className="flex gap-3 mb-3 last:mb-0">
                  <img
                    src={item.image || `https://picsum.photos/seed/${item.product}/80/80`}
                    alt={item.name}
                    className="w-16 h-16 object-contain border rounded bg-gray-50"
                  />
                  <div>
                    <p className="text-sm font-medium">{item.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5">Qty: {item.qty} · ₹{item.price?.toLocaleString()} each</p>
                  </div>
                </div>
              ))}

              {order.orderItems?.length > 2 && (
                <button
                  onClick={() => setExpanded(expanded === order._id ? null : order._id)}
                  className="text-amazon-blue text-xs hover:underline mt-1"
                >
                  {expanded === order._id ? 'Show less' : `+ ${order.orderItems.length - 2} more item(s)`}
                </button>
              )}

              {/* Delivery info */}
              {order.estimatedDelivery && order.status !== 'Delivered' && order.status !== 'Cancelled' && (
                <p className="text-sm text-gray-600 mt-3">
                  📦 Estimated delivery: <strong>{new Date(order.estimatedDelivery).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</strong>
                </p>
              )}

              {/* Actions */}
              <div className="flex gap-3 mt-4 flex-wrap">
                <Link href={`/orders/${order._id}`} className="btn-secondary text-xs flex items-center gap-1">
                  View Details <FiChevronRight size={12} />
                </Link>
                {['Confirmed', 'Processing'].includes(order.status) && (
                  <CancelOrderButton orderId={order._id} onCancelled={fetchOrders} />
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CancelOrderButton({ orderId, onCancelled }) {
  const [loading, setLoading] = useState(false);
  const handleCancel = async () => {
    if (!confirm('Cancel this order?')) return;
    setLoading(true);
    try {
      const client = apiClient();
      await client.put(`/orders/${orderId}/cancel`);
      onCancelled();
    } catch { } finally {
      setLoading(false);
    }
  };
  return (
    <button onClick={handleCancel} disabled={loading} className="text-xs text-red-600 border border-red-300 rounded px-3 py-1.5 hover:bg-red-50 disabled:opacity-50">
      {loading ? 'Cancelling...' : 'Cancel Order'}
    </button>
  );
}
