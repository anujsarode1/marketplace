'use client';
import { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import { apiClient } from '@/store';
import Link from 'next/link';
import { FiCheckCircle, FiPackage, FiTruck, FiHome } from 'react-icons/fi';

const STATUS_STEPS = ['Confirmed', 'Processing', 'Shipped', 'Out for Delivery', 'Delivered'];
const STATUS_COLORS = {
  Confirmed: 'text-blue-600', Processing: 'text-yellow-600', Shipped: 'text-purple-600',
  'Out for Delivery': 'text-orange-600', Delivered: 'text-green-600', Cancelled: 'text-red-600',
};

export default function OrderDetailPage() {
  const { id } = useParams();
  const searchParams = useSearchParams();
  const isSuccess = searchParams.get('success') === '1';
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    const fetchOrder = async () => {
      try {
        const client = apiClient();
        const { data } = await client.get(`/orders/${id}`);
        setOrder(data.order);
      } catch { } finally { setLoading(false); }
    };
    fetchOrder();
  }, [id]);

  if (loading) return <div className="flex justify-center py-20"><div className="animate-spin w-8 h-8 border-4 border-amazon-yellow border-t-transparent rounded-full" /></div>;
  if (!order) return <div className="text-center py-20">Order not found</div>;

  const stepIndex = STATUS_STEPS.indexOf(order.status);
  const cancelled = order.status === 'Cancelled';

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      {/* Success banner */}
      {isSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center mb-6">
          <FiCheckCircle size={56} className="text-green-500 mx-auto mb-3" />
          <h1 className="text-2xl font-bold text-green-800 mb-1">Order Placed Successfully!</h1>
          <p className="text-green-700">Thank you! Your order has been confirmed.</p>
          <p className="text-sm text-green-600 mt-2">Order ID: <strong>#{id.slice(-8).toUpperCase()}</strong></p>
          {order.estimatedDelivery && (
            <p className="text-sm text-green-600">
              Estimated Delivery: <strong>{new Date(order.estimatedDelivery).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</strong>
            </p>
          )}
        </div>
      )}

      {/* Order header */}
      <div className="bg-white rounded shadow-sm p-4 mb-4">
        <div className="flex justify-between items-start flex-wrap gap-3">
          <div>
            <h2 className="text-lg font-bold">Order #{id.slice(-8).toUpperCase()}</h2>
            <p className="text-sm text-gray-500">Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
          </div>
          <span className={`font-bold text-sm ${STATUS_COLORS[order.status] || ''}`}>{order.status}</span>
        </div>

        {/* Tracking bar */}
        {!cancelled && (
          <div className="mt-5">
            <div className="flex justify-between relative">
              <div className="absolute top-3 left-0 right-0 h-1 bg-gray-200">
                <div
                  className="h-full bg-amazon-yellow transition-all duration-500"
                  style={{ width: `${(stepIndex / (STATUS_STEPS.length - 1)) * 100}%` }}
                />
              </div>
              {STATUS_STEPS.map((s, i) => (
                <div key={s} className="flex flex-col items-center z-10">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center text-xs font-bold
                    ${i <= stepIndex ? 'border-amazon-yellow bg-amazon-yellow text-black' : 'border-gray-300 bg-white text-gray-400'}`}>
                    {i < stepIndex ? '✓' : i + 1}
                  </div>
                  <span className="text-xs mt-1 text-center w-16 leading-tight text-gray-600">{s}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Items */}
      <div className="bg-white rounded shadow-sm p-4 mb-4">
        <h3 className="font-bold mb-3 border-b pb-2">Items Ordered</h3>
        {order.orderItems?.map((item, i) => (
          <div key={i} className="flex gap-4 py-3 border-b last:border-0">
            <img
              src={item.image || `https://picsum.photos/seed/${item.product?._id || i}/80/80`}
              alt={item.name}
              className="w-20 h-20 object-contain border rounded bg-gray-50"
            />
            <div className="flex-1">
              <p className="font-medium text-sm">{item.name}</p>
              <p className="text-xs text-gray-500 mt-1">Qty: {item.qty}</p>
              <p className="text-sm font-bold mt-1">₹{item.price?.toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className="font-bold">₹{(item.price * item.qty)?.toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        {/* Shipping address */}
        <div className="bg-white rounded shadow-sm p-4">
          <h3 className="font-bold mb-2 flex items-center gap-2"><FiHome size={16} /> Delivery Address</h3>
          <div className="text-sm text-gray-700 space-y-0.5">
            <p className="font-medium">{order.shippingAddress?.name}</p>
            <p>{order.shippingAddress?.street}</p>
            <p>{order.shippingAddress?.city}, {order.shippingAddress?.state}</p>
            <p>{order.shippingAddress?.pincode}</p>
            <p>📞 {order.shippingAddress?.phone}</p>
          </div>
        </div>

        {/* Payment */}
        <div className="bg-white rounded shadow-sm p-4">
          <h3 className="font-bold mb-2">Payment & Summary</h3>
          <div className="text-sm space-y-1.5">
            <div className="flex justify-between">
              <span className="text-gray-600">Method:</span>
              <span>{order.paymentMethod}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Items:</span>
              <span>₹{order.itemsPrice?.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Shipping:</span>
              <span>{order.shippingPrice === 0 ? 'FREE' : `₹${order.shippingPrice}`}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Tax:</span>
              <span>₹{order.taxPrice?.toLocaleString()}</span>
            </div>
            <div className="flex justify-between font-bold border-t pt-1.5">
              <span>Grand Total:</span>
              <span>₹{order.totalPrice?.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-3 flex-wrap">
        <Link href="/orders" className="btn-secondary">Back to Orders</Link>
        <Link href="/" className="btn-primary">Continue Shopping</Link>
      </div>
    </div>
  );
}
