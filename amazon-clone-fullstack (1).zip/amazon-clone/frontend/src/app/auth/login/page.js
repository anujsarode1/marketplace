'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useAuthStore } from '@/store';

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirect = searchParams.get('redirect') || '/';
  const { login, loading } = useAuthStore();
  const [form, setForm] = useState({ email: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await login(form.email, form.password);
    if (result.success) router.push(redirect);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center py-8 px-4">
      <Link href="/" className="text-3xl font-bold mb-6">
        amazon<span className="text-amazon-yellow">.in</span>
      </Link>
      <div className="bg-white rounded-lg shadow-sm p-6 w-full max-w-sm border border-gray-300">
        <h1 className="text-2xl font-bold mb-5">Sign in</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Email address</label>
            <input
              type="email"
              required
              value={form.email}
              onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              className="input-field"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input
              type="password"
              required
              value={form.password}
              onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
              className="input-field"
              placeholder="At least 6 characters"
            />
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full py-2.5 disabled:opacity-50">
            {loading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>
        <p className="text-xs text-gray-500 mt-4 text-center">
          By continuing, you agree to our Terms and Privacy Notice.
        </p>
      </div>

      <div className="mt-4 text-center">
        <p className="text-sm text-gray-600">New to Amazon Clone?</p>
        <Link href={`/auth/register?redirect=${redirect}`} className="btn-secondary inline-block mt-2 w-full max-w-sm text-center">
          Create your Amazon account
        </Link>
      </div>
    </div>
  );
}
