'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useAuthStore } from '@/store';

export default function RegisterPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirect = searchParams.get('redirect') || '/';
  const { register, loading } = useAuthStore();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirm) { setError('Passwords do not match'); return; }
    if (form.password.length < 6) { setError('Password must be at least 6 characters'); return; }
    setError('');
    const result = await register(form.name, form.email, form.password);
    if (result.success) router.push(redirect);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center py-8 px-4">
      <Link href="/" className="text-3xl font-bold mb-6">
        amazon<span className="text-amazon-yellow">.in</span>
      </Link>
      <div className="bg-white rounded-lg shadow-sm p-6 w-full max-w-sm border border-gray-300">
        <h1 className="text-2xl font-bold mb-5">Create account</h1>
        {error && <div className="bg-red-50 border border-red-400 text-red-700 text-sm p-3 rounded mb-4">{error}</div>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Your name</label>
            <input type="text" required value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="input-field" placeholder="First and last name" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Email address</label>
            <input type="email" required value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className="input-field" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input type="password" required value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} className="input-field" placeholder="At least 6 characters" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Re-enter password</label>
            <input type="password" required value={form.confirm} onChange={e => setForm(f => ({ ...f, confirm: e.target.value }))} className="input-field" />
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full py-2.5 disabled:opacity-50">
            {loading ? 'Creating account...' : 'Create your Amazon account'}
          </button>
        </form>
      </div>
      <div className="mt-4 text-center text-sm">
        Already have an account?{' '}
        <Link href={`/auth/login?redirect=${redirect}`} className="text-amazon-blue hover:underline font-medium">Sign in</Link>
      </div>
    </div>
  );
}
