'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import axios from 'axios';
import { useCartStore, useWishlistStore, useAuthStore, useRecentlyViewedStore } from '@/store';
import { AiFillStar, AiOutlineStar, AiFillHeart } from 'react-icons/ai';
import { FiHeart, FiShoppingCart, FiShare2, FiShield, FiTruck, FiRefreshCw } from 'react-icons/fi';
import Link from 'next/link';
import toast from 'react-hot-toast';
import ProductCard from '@/components/product/ProductCard';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

export default function ProductDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const { addToCart } = useCartStore();
  const { toggle, isWishlisted } = useWishlistStore();
  const { user, token } = useAuthStore();
  const { add: addRecentlyViewed } = useRecentlyViewedStore();

  const [product, setProduct] = useState(null);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [qty, setQty] = useState(1);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);
  const [activeTab, setActiveTab] = useState('description');

  useEffect(() => {
    if (!id) return;
    fetchProduct();
  }, [id]);

  const fetchProduct = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${API}/products/${id}`);
      setProduct(data.product);
      addRecentlyViewed(data.product);
      // Fetch related
      const rel = await axios.get(`${API}/products?category=${data.product.category}&limit=4`);
      setRelated(rel.data.products.filter(p => p._id !== id));
    } catch {
      toast.error('Product not found');
      router.push('/');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = () => {
    addToCart(product, qty);
  };

  const handleBuyNow = () => {
    addToCart(product, qty);
    router.push('/cart');
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!user) { toast.error('Please login to review'); router.push('/auth/login'); return; }
    setSubmittingReview(true);
    try {
      await axios.post(`${API}/products/${id}/reviews`, reviewForm, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Review submitted!');
      setReviewForm({ rating: 5, comment: '' });
      fetchProduct();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit review');
    } finally {
      setSubmittingReview(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-pulse">
          <div className="bg-gray-200 h-96 rounded" />
          <div className="space-y-4">
            <div className="h-8 bg-gray-200 rounded w-3/4" />
            <div className="h-4 bg-gray-200 rounded w-1/2" />
            <div className="h-6 bg-gray-200 rounded w-1/4" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) return null;

  const wishlisted = isWishlisted(product._id);
  const inStock = product.stock > 0;
  const images = product.images?.length ? product.images : [`https://picsum.photos/seed/${product._id}/400/400`];

  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-4">
        {/* Breadcrumb */}
        <nav className="text-sm text-amazon-blue mb-4 flex gap-1">
          <Link href="/" className="hover:underline">Home</Link>
          <span className="text-gray-400">›</span>
          <Link href={`/search?category=${product.category}`} className="hover:underline">{product.category}</Link>
          <span className="text-gray-400">›</span>
          <span className="text-gray-600 truncate">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Images - Left */}
          <div className="md:col-span-5">
            <div className="sticky top-20">
              {/* Main Image */}
              <div className="border border-gray-200 rounded-lg overflow-hidden bg-gray-50 h-80 md:h-96 flex items-center justify-center mb-3">
                <img
                  src={images[selectedImage]}
                  alt={product.name}
                  className="max-h-full max-w-full object-contain p-4 hover:scale-110 transition-transform duration-300"
                />
              </div>
              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {images.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedImage(i)}
                      className={`flex-shrink-0 w-16 h-16 border-2 rounded overflow-hidden ${i === selectedImage ? 'border-amazon-yellow' : 'border-gray-200'}`}
                    >
                      <img src={img} alt="" className="w-full h-full object-contain p-1" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Product Info - Center */}
          <div className="md:col-span-5 space-y-4">
            <div>
              <h1 className="text-xl font-medium text-gray-900 leading-snug">{product.name}</h1>
              {product.brand && (
                <p className="text-amazon-blue text-sm mt-1">
                  Brand: <Link href={`/search?q=${product.brand}`} className="hover:underline">{product.brand}</Link>
                </p>
              )}
            </div>

            {/* Rating */}
            <div className="flex items-center gap-2 border-b pb-3">
              <div className="flex text-amazon-yellow">
                {[1,2,3,4,5].map(s => (
                  s <= Math.round(product.rating)
                    ? <AiFillStar key={s} size={18} />
                    : <AiOutlineStar key={s} size={18} className="text-gray-300" />
                ))}
              </div>
              <a href="#reviews" className="text-amazon-blue text-sm hover:underline">
                {product.numReviews?.toLocaleString()} ratings
              </a>
            </div>

            {/* Price */}
            <div className="border-b pb-4">
              {product.originalPrice > product.price && (
                <div className="text-sm text-gray-500">
                  M.R.P.: <span className="line-through">₹{product.originalPrice?.toLocaleString()}</span>
                  <span className="text-red-600 font-medium ml-2">({product.discount}% off)</span>
                </div>
              )}
              <div className="text-3xl font-bold text-gray-900 mt-1">
                ₹{product.price?.toLocaleString()}
              </div>
              <p className="text-xs text-gray-500 mt-1">Inclusive of all taxes</p>
            </div>

            {/* Delivery */}
            <div className="text-sm space-y-2">
              <div className="flex items-center gap-2">
                <FiTruck className="text-gray-600" size={16} />
                <span>FREE delivery <strong>Tomorrow</strong> on orders over ₹499</span>
              </div>
              <div className="flex items-center gap-2">
                <FiRefreshCw className="text-gray-600" size={16} />
                <span>10 days Replacement</span>
              </div>
              <div className="flex items-center gap-2">
                <FiShield className="text-gray-600" size={16} />
                <span>1 Year Manufacturer Warranty</span>
              </div>
            </div>

            {/* Stock */}
            <div>
              {inStock ? (
                <p className="text-amazon-green font-bold text-lg">In Stock</p>
              ) : (
                <p className="text-red-600 font-bold text-lg">Out of Stock</p>
              )}
              {product.stock > 0 && product.stock <= 10 && (
                <p className="text-red-600 text-sm">Only {product.stock} left in stock – order soon</p>
              )}
            </div>

            {/* Specs */}
            {product.specs?.length > 0 && (
              <div>
                <h3 className="font-medium mb-2">Specifications</h3>
                <table className="text-sm w-full">
                  <tbody>
                    {product.specs.map((s, i) => (
                      <tr key={i} className={i % 2 === 0 ? 'bg-gray-50' : ''}>
                        <td className="py-1.5 px-2 text-gray-600 w-1/3">{s.key}</td>
                        <td className="py-1.5 px-2 font-medium">{s.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Tags */}
            {product.tags?.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {product.tags.map(t => (
                  <Link key={t} href={`/search?q=${t}`}>
                    <span className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-600 px-2 py-1 rounded-full cursor-pointer">#{t}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Buy Box - Right */}
          <div className="md:col-span-2">
            <div className="border border-gray-200 rounded-lg p-4 sticky top-20 space-y-3">
              <div className="text-xl font-bold">₹{product.price?.toLocaleString()}</div>
              {product.originalPrice > product.price && (
                <div className="text-xs text-gray-500">You save: ₹{(product.originalPrice - product.price).toLocaleString()} ({product.discount}%)</div>
              )}
              <div className={`text-sm font-medium ${inStock ? 'text-amazon-green' : 'text-red-600'}`}>
                {inStock ? 'In Stock' : 'Out of Stock'}
              </div>

              {/* Qty selector */}
              {inStock && (
                <div className="flex items-center gap-2">
                  <label className="text-sm">Qty:</label>
                  <select
                    value={qty}
                    onChange={e => setQty(Number(e.target.value))}
                    className="border border-gray-300 rounded px-2 py-1 text-sm bg-gray-50"
                  >
                    {Array.from({ length: Math.min(10, product.stock) }, (_, i) => (
                      <option key={i + 1} value={i + 1}>{i + 1}</option>
                    ))}
                  </select>
                </div>
              )}

              <button onClick={handleAddToCart} disabled={!inStock} className="btn-primary w-full disabled:opacity-50">
                Add to Cart
              </button>
              <button onClick={handleBuyNow} disabled={!inStock} className="btn-orange w-full disabled:opacity-50">
                Buy Now
              </button>
              <button
                onClick={() => toggle(product)}
                className="w-full flex items-center justify-center gap-2 text-sm border border-gray-300 rounded py-1.5 hover:bg-gray-50"
              >
                {wishlisted ? <AiFillHeart className="text-red-500" /> : <FiHeart />}
                {wishlisted ? 'In Wishlist' : 'Add to Wishlist'}
              </button>

              <div className="text-xs text-gray-500 border-t pt-2 space-y-1">
                <p>Sold by: <span className="text-amazon-blue">{product.brand || 'Amazon Seller'}</span></p>
                <p>Ships from: Amazon</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs: Description, Reviews */}
        <div className="mt-10" id="reviews">
          <div className="flex border-b mb-6">
            {['description', 'reviews'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-3 text-sm font-medium capitalize border-b-2 transition-colors ${activeTab === tab ? 'border-amazon-yellow text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
              >
                {tab} {tab === 'reviews' && `(${product.numReviews})`}
              </button>
            ))}
          </div>

          {activeTab === 'description' && (
            <div className="prose max-w-none text-gray-700 text-sm leading-relaxed">
              <p>{product.description}</p>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {/* Rating summary */}
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="text-center">
                  <div className="text-5xl font-bold">{product.rating}</div>
                  <div className="flex text-amazon-yellow justify-center mt-1">
                    {[1,2,3,4,5].map(s => (
                      <AiFillStar key={s} size={16} className={s <= product.rating ? 'text-amazon-yellow' : 'text-gray-300'} />
                    ))}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">{product.numReviews} ratings</div>
                </div>
              </div>

              {/* Review list */}
              {product.reviews?.length > 0 ? (
                <div className="space-y-4">
                  {product.reviews.map((r, i) => (
                    <div key={i} className="border-b pb-4">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-8 h-8 rounded-full bg-amazon-light text-white flex items-center justify-center text-sm font-bold">
                          {r.name?.[0]?.toUpperCase()}
                        </div>
                        <span className="font-medium text-sm">{r.name}</span>
                      </div>
                      <div className="flex text-amazon-yellow mb-1">
                        {[1,2,3,4,5].map(s => (
                          <AiFillStar key={s} size={14} className={s <= r.rating ? 'text-amazon-yellow' : 'text-gray-300'} />
                        ))}
                      </div>
                      <p className="text-sm text-gray-700">{r.comment}</p>
                      <p className="text-xs text-gray-400 mt-1">{new Date(r.createdAt).toLocaleDateString()}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-sm">No reviews yet. Be the first to review!</p>
              )}

              {/* Write review */}
              <div className="border-t pt-6">
                <h3 className="font-medium mb-4">Write a Customer Review</h3>
                {user ? (
                  <form onSubmit={handleReviewSubmit} className="space-y-3 max-w-lg">
                    <div>
                      <label className="block text-sm mb-1">Your Rating</label>
                      <div className="flex gap-1">
                        {[1,2,3,4,5].map(s => (
                          <button key={s} type="button" onClick={() => setReviewForm(f => ({ ...f, rating: s }))}>
                            <AiFillStar size={28} className={s <= reviewForm.rating ? 'text-amazon-yellow' : 'text-gray-300'} />
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm mb-1">Your Review</label>
                      <textarea
                        value={reviewForm.comment}
                        onChange={e => setReviewForm(f => ({ ...f, comment: e.target.value }))}
                        rows={4}
                        required
                        placeholder="What did you think of this product?"
                        className="input-field resize-none"
                      />
                    </div>
                    <button type="submit" disabled={submittingReview} className="btn-primary disabled:opacity-50">
                      {submittingReview ? 'Submitting...' : 'Submit Review'}
                    </button>
                  </form>
                ) : (
                  <p className="text-sm">
                    <Link href="/auth/login" className="link font-medium">Sign in</Link> to write a review
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <div className="mt-12">
            <h2 className="text-xl font-bold mb-4">Related Products</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {related.map(p => <ProductCard key={p._id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
