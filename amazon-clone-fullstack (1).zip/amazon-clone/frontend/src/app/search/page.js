'use client';
import { useState, useEffect, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import axios from 'axios';
import ProductGrid from '@/components/product/ProductGrid';
import { FiFilter, FiX } from 'react-icons/fi';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';
const CATEGORIES = ['Electronics', 'Clothing', 'Books', 'Kitchen', 'Sports', 'Beauty'];

function SearchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const q = searchParams.get('q') || '';
  const cat = searchParams.get('category') || '';
  const featured = searchParams.get('featured') || '';
  const bestseller = searchParams.get('bestseller') || '';
  const sortParam = searchParams.get('sort') || '';

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({
    category: cat,
    minPrice: '',
    maxPrice: '',
    rating: '',
    sort: sortParam,
  });

  useEffect(() => {
    setFilters(f => ({ ...f, category: cat, sort: sortParam }));
    setPage(1);
  }, [cat, sortParam]);

  useEffect(() => {
    fetchProducts();
  }, [q, filters, page, featured, bestseller]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (q) params.set('keyword', q);
      if (filters.category) params.set('category', filters.category);
      if (filters.minPrice) params.set('minPrice', filters.minPrice);
      if (filters.maxPrice) params.set('maxPrice', filters.maxPrice);
      if (filters.rating) params.set('rating', filters.rating);
      if (filters.sort) params.set('sort', filters.sort);
      if (featured) params.set('featured', featured);
      if (bestseller) params.set('bestseller', bestseller);
      params.set('page', page);
      params.set('limit', 12);

      const { data } = await axios.get(`${API}/products?${params}`);
      setProducts(data.products || []);
      setTotal(data.total || 0);
      setPages(data.pages || 1);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const updateFilter = (key, value) => {
    setFilters(f => ({ ...f, [key]: value }));
    setPage(1);
  };

  const clearFilters = () => {
    setFilters({ category: '', minPrice: '', maxPrice: '', rating: '', sort: '' });
    setPage(1);
    router.push('/search');
  };

  const getTitle = () => {
    if (q) return `Results for "${q}"`;
    if (featured === 'true') return "Today's Deals";
    if (bestseller === 'true') return 'Bestsellers';
    if (filters.category) return filters.category;
    return 'All Products';
  };

  const FilterPanel = () => (
    <div className="bg-white rounded shadow-sm p-4 space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-gray-800">Filters</h3>
        <button onClick={clearFilters} className="text-amazon-blue text-xs hover:underline">Clear all</button>
      </div>

      {/* Category */}
      <div>
        <h4 className="font-semibold text-sm text-gray-700 mb-2">Category</h4>
        <div className="space-y-1">
          {CATEGORIES.map(c => (
            <label key={c} className="flex items-center gap-2 cursor-pointer hover:text-amazon-blue text-sm">
              <input type="radio" name="cat" checked={filters.category === c}
                onChange={() => updateFilter('category', c)} className="accent-amazon-yellow" />
              {c}
            </label>
          ))}
          <label className="flex items-center gap-2 cursor-pointer hover:text-amazon-blue text-sm">
            <input type="radio" name="cat" checked={filters.category === ''}
              onChange={() => updateFilter('category', '')} className="accent-amazon-yellow" />
            All Categories
          </label>
        </div>
      </div>

      {/* Price Range */}
      <div>
        <h4 className="font-semibold text-sm text-gray-700 mb-2">Price Range (₹)</h4>
        <div className="flex gap-2">
          <input type="number" placeholder="Min" value={filters.minPrice}
            onChange={e => updateFilter('minPrice', e.target.value)}
            className="input-field" />
          <input type="number" placeholder="Max" value={filters.maxPrice}
            onChange={e => updateFilter('maxPrice', e.target.value)}
            className="input-field" />
        </div>
      </div>

      {/* Rating */}
      <div>
        <h4 className="font-semibold text-sm text-gray-700 mb-2">Min Rating</h4>
        {[4, 3, 2, 1].map(r => (
          <label key={r} className="flex items-center gap-2 cursor-pointer text-sm">
            <input type="radio" name="rating" checked={filters.rating === String(r)}
              onChange={() => updateFilter('rating', String(r))} className="accent-amazon-yellow" />
            <span className="text-amazon-yellow">{'★'.repeat(r)}{'☆'.repeat(5 - r)}</span>
            <span className="text-gray-500">& above</span>
          </label>
        ))}
        <label className="flex items-center gap-2 cursor-pointer text-sm">
          <input type="radio" name="rating" checked={filters.rating === ''}
            onChange={() => updateFilter('rating', '')} className="accent-amazon-yellow" />
          <span className="text-gray-500">Any rating</span>
        </label>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-gray-800">{getTitle()}</h1>
          {!loading && <p className="text-sm text-gray-500">{total.toLocaleString()} results</p>}
        </div>
        <div className="flex items-center gap-3">
          {/* Mobile filter toggle */}
          <button onClick={() => setShowFilters(!showFilters)} className="md:hidden btn-secondary flex items-center gap-1">
            <FiFilter size={14} /> Filters
          </button>
          {/* Sort */}
          <select
            value={filters.sort}
            onChange={e => updateFilter('sort', e.target.value)}
            className="input-field w-auto text-sm"
          >
            <option value="">Sort: Featured</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="rating">Avg. Customer Review</option>
            <option value="newest">Newest Arrivals</option>
          </select>
        </div>
      </div>

      {/* Mobile filter panel */}
      {showFilters && (
        <div className="md:hidden mb-4">
          <FilterPanel />
        </div>
      )}

      <div className="flex gap-4">
        {/* Sidebar */}
        <aside className="hidden md:block w-56 flex-shrink-0">
          <FilterPanel />
        </aside>

        {/* Products */}
        <div className="flex-1">
          <ProductGrid products={products} loading={loading} />

          {/* Pagination */}
          {pages > 1 && (
            <div className="flex justify-center gap-2 mt-8">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="btn-secondary disabled:opacity-40">← Prev</button>
              {Array.from({ length: pages }, (_, i) => i + 1).filter(p => Math.abs(p - page) <= 2).map(p => (
                <button key={p} onClick={() => setPage(p)}
                  className={p === page ? 'btn-primary' : 'btn-secondary'}>
                  {p}
                </button>
              ))}
              <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages}
                className="btn-secondary disabled:opacity-40">Next →</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="max-w-7xl mx-auto px-4 py-6"><ProductGrid products={[]} loading={true} /></div>}>
      <SearchContent />
    </Suspense>
  );
}
