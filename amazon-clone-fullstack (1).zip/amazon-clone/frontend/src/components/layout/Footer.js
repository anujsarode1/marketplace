'use client';
import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-amazon text-white mt-8">
      {/* Back to top */}
      <div
        className="bg-amazon-light text-center py-3 text-sm cursor-pointer hover:bg-gray-600 transition-colors"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        Back to top
      </div>

      {/* Links */}
      <div className="max-w-7xl mx-auto px-4 py-10 grid grid-cols-2 md:grid-cols-4 gap-8">
        {[
          { title: 'Get to Know Us', links: ['About Us', 'Careers', 'Press Releases', 'Amazon Science'] },
          { title: 'Connect with Us', links: ['Facebook', 'Twitter', 'Instagram'] },
          { title: 'Make Money with Us', links: ['Sell on Amazon', 'Advertise Your Products', 'Become an Affiliate'] },
          { title: 'Let Us Help You', links: ['Your Account', 'Returns', 'Help'] },
        ].map(col => (
          <div key={col.title}>
            <h3 className="font-bold text-sm mb-3">{col.title}</h3>
            <ul className="space-y-2">
              {col.links.map(l => (
                <li key={l}><Link href="#" className="text-gray-400 text-xs hover:text-white">{l}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-600 py-4 text-center text-xs text-gray-400">
        <div className="flex justify-center gap-4 mb-2 flex-wrap">
          {['Conditions of Use', 'Privacy Notice', 'Interest-Based Ads'].map(l => (
            <Link key={l} href="#" className="hover:underline">{l}</Link>
          ))}
        </div>
        <p>© 2024 Amazon Clone. All rights reserved.</p>
      </div>
    </footer>
  );
}
