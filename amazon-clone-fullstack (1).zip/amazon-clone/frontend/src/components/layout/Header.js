'use client';
import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useAuthStore, useCartStore, useWishlistStore } from '@/store';
import { FiSearch, FiShoppingCart, FiHeart, FiUser, FiMenu, FiX, FiMapPin, FiChevronDown } from 'react-icons/fi';
import axios from 'axios';

const CATEGORIES = ['All', 'Electronics', 'Clothing', 'Books', 'Kitchen', 'Sports', 'Beauty'];
const API = process.env.NEXT_PUBLIC_API_URL;

export default function Header() {
  const router = useRouter();
  const { user, logout } = useAuthStore();
  const { items: cartItems } = useCartStore();
  const { items: wishlistItems } = useWishlistStore();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [userMenu, setUserMenu] = useState(false);
  const searchRef = useRef(null);

  const cartCount = cartItems.reduce((s, i) => s + i.qty, 0);

  useEffect(() => {
    const handler = (e) => {
      if (!searchRef.current?.contains(e.target)) setShowSuggestions(false);
      setUserMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    if (search.length < 2) { setSuggestions([]); return; }
    const timer = setTimeout(async () => {
      try {
        const { data } = await axios.get(`${API}/products?keyword=${search}&limit=5`);
        setSuggestions(data.products || []);
      } catch {}
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) router.push(`/search?q=${encodeURIComponent(search.trim())}&category=${category}`);
    setShowSuggestions(false);
  };

  return (
    <header className="sticky top-0 z-50">
      {/* Main header */}
      <div className="bg-amazon text-white">
        <div className="max-w-7xl mx-auto px-3 py-2 flex items-center gap-3">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0 flex items-center gap-1">
            <span className="text-white font-bold text-2xl tracking-tight">amazon</span>
            <span className="text-amazon-yellow text-2xl">.in</span>
          </Link>

          {/* Deliver to */}
          <Link href="/account/addresses" className="hidden md:flex items-center gap-1 text-xs flex-shrink-0 hover:outline outline-white px-1 py-1 rounded">
            <FiMapPin className="text-amazon-yellow" size={14} />
            <div>
              <div className="text-gray-300 text-xs">Deliver to</div>
              <div className="font-bold text-sm">{user?.addresses?.[0]?.city || 'India'}</div>
            </div>
          </Link>

          {/* Search */}
          <div className="flex-1 relative" ref={searchRef}>
            <form onSubmit={handleSearch} className="flex">
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="bg-gray-200 text-black text-xs px-2 rounded-l border-r border-gray-400 hidden md:block"
              >
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
              <input
                type="text"
                value={search}
                onChange={e => { setSearch(e.target.value); setShowSuggestions(true); }}
                placeholder="Search Amazon.in"
                className="flex-1 px-3 py-2 text-black text-sm focus:outline-none"
              />
              <button type="submit" className="bg-amazon-yellow hover:bg-amazon-yellow-hover px-4 rounded-r flex items-center">
                <FiSearch className="text-black" size={20} />
              </button>
            </form>

            {/* Search suggestions */}
            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 bg-white shadow-xl z-50 border border-gray-200 rounded-b">
                {suggestions.map(p => (
                  <div
                    key={p._id}
                    onClick={() => { router.push(`/product/${p._id}`); setShowSuggestions(false); setSearch(''); }}
                    className="flex items-center gap-3 px-4 py-2 hover:bg-gray-100 cursor-pointer text-black"
                  >
                    <FiSearch size={14} className="text-gray-400" />
                    <span className="text-sm">{p.name}</span>
                    <span className="text-xs text-gray-500 ml-auto">₹{p.price.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right icons */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {/* Account */}
            <div className="relative">
              <button
                onClick={() => setUserMenu(!userMenu)}
                className="text-xs hover:outline outline-white px-1 py-1 rounded flex items-center gap-1"
              >
                <div>
                  <div className="text-gray-300">Hello, {user ? user.name.split(' ')[0] : 'Sign in'}</div>
                  <div className="font-bold text-sm flex items-center gap-1">Account <FiChevronDown size={12} /></div>
                </div>
              </button>
              {userMenu && (
                <div className="absolute right-0 top-full mt-1 w-48 bg-white shadow-xl rounded z-50 border text-black text-sm">
                  {user ? (
                    <>
                      <Link href="/account" className="block px-4 py-2 hover:bg-gray-100">My Account</Link>
                      <Link href="/orders" className="block px-4 py-2 hover:bg-gray-100">Orders</Link>
                      <Link href="/wishlist" className="block px-4 py-2 hover:bg-gray-100">Wishlist</Link>
                      <hr />
                      <button onClick={logout} className="block w-full text-left px-4 py-2 hover:bg-gray-100 text-red-600">Sign Out</button>
                    </>
                  ) : (
                    <>
                      <Link href="/auth/login" className="block px-4 py-2 hover:bg-gray-100 font-semibold">Sign In</Link>
                      <Link href="/auth/register" className="block px-4 py-2 hover:bg-gray-100">Create Account</Link>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Wishlist */}
            <Link href="/wishlist" className="hidden md:flex flex-col text-xs hover:outline outline-white px-1 py-1 rounded">
              <span className="text-gray-300">Wish</span>
              <span className="font-bold flex items-center gap-1">
                <FiHeart size={14} />
                {wishlistItems.length > 0 && <span className="text-amazon-yellow">{wishlistItems.length}</span>}
                List
              </span>
            </Link>

            {/* Cart */}
            <Link href="/cart" className="flex items-end gap-1 hover:outline outline-white px-1 py-1 rounded relative">
              <div className="relative">
                <FiShoppingCart size={28} />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-1 bg-amazon-yellow text-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                    {cartCount > 99 ? '99+' : cartCount}
                  </span>
                )}
              </div>
              <span className="font-bold text-sm hidden md:block">Cart</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Navigation bar */}
      <div className="bg-amazon-light text-white text-sm">
        <div className="max-w-7xl mx-auto px-3 py-1 flex items-center gap-4 overflow-x-auto">
          <button onClick={() => setMobileMenu(!mobileMenu)} className="flex items-center gap-1 hover:outline outline-white px-2 py-1 rounded whitespace-nowrap">
            {mobileMenu ? <FiX size={16} /> : <FiMenu size={16} />} All
          </button>
          {CATEGORIES.slice(1).map(cat => (
            <Link key={cat} href={`/search?category=${cat}`} className="hover:text-amazon-yellow whitespace-nowrap py-1 px-1">
              {cat}
            </Link>
          ))}
          <Link href="/search?featured=true" className="hover:text-amazon-yellow whitespace-nowrap py-1 px-1">Today's Deals</Link>
          <Link href="/search?bestseller=true" className="hover:text-amazon-yellow whitespace-nowrap py-1 px-1">Bestsellers</Link>
          <Link href="/search?newest=true" className="hover:text-amazon-yellow whitespace-nowrap py-1 px-1">New Arrivals</Link>
        </div>
      </div>
    </header>
  );
}
