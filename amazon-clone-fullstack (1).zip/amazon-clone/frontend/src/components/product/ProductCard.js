'use client';
import Link from 'next/link';
import Image from 'next/image';
import { FiHeart } from 'react-icons/fi';
import { FaHeart } from 'react-icons/fa';
import { useCartStore, useWishlistStore } from '@/store';

function StarRating({ rating, count }) {
  return (
    <div className="flex items-center gap-1 text-xs">
      <div className="flex text-amazon-yellow">
        {[1,2,3,4,5].map(s => (
          <span key={s}>{s <= Math.round(rating) ? '★' : '☆'}</span>
        ))}
      </div>
      {count !== undefined && <span className="text-amazon-blue">({count.toLocaleString()})</span>}
    </div>
  );
}

export default function ProductCard({ product }) {
  const { addToCart } = useCartStore();
  const { toggle, isWishlisted } = useWishlistStore();
  const wishlisted = isWishlisted(product._id);

  const discountPct = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : product.discount || 0;

  return (
    <div className="product-card bg-white rounded shadow-sm hover:shadow-md transition-shadow flex flex-col group relative">
      {/* Wishlist btn */}
      <button
        onClick={() => toggle(product)}
        className="absolute top-2 right-2 z-10 bg-white rounded-full p-1.5 shadow opacity-0 group-hover:opacity-100 transition-opacity"
      >
        {wishlisted ? <FaHeart className="text-red-500" size={16} /> : <FiHeart size={16} className="text-gray-500" />}
      </button>

      {/* Badges */}
      <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
        {product.isBestseller && <span className="badge bg-amazon-yellow text-black text-[10px]">Best Seller</span>}
        {product.isNew && <span className="badge bg-red-600 text-white text-[10px]">New</span>}
        {discountPct >= 20 && <span className="badge bg-red-100 text-red-700 text-[10px]">-{discountPct}%</span>}
      </div>

      {/* Image */}
      <Link href={`/product/${product._id}`} className="block overflow-hidden bg-gray-50 rounded-t">
        <div className="relative h-52 w-full">
          <Image
            src={product.images?.[0] || `https://picsum.photos/seed/${product._id}/400/400`}
            alt={product.name}
            fill
            className="object-contain p-4 group-hover:scale-105 transition-transform duration-300"
            sizes="(max-width: 768px) 50vw, 25vw"
          />
        </div>
      </Link>

      {/* Info */}
      <div className="p-3 flex flex-col flex-1">
        <Link href={`/product/${product._id}`}>
          <h3 className="text-sm font-medium text-gray-800 line-clamp-2 hover:text-amazon-blue leading-snug mb-1">
            {product.name}
          </h3>
        </Link>

        <StarRating rating={product.rating} count={product.numReviews} />

        <div className="mt-2 flex items-baseline gap-2 flex-wrap">
          <span className="text-lg font-bold text-gray-900">₹{product.price.toLocaleString()}</span>
          {product.originalPrice && product.originalPrice > product.price && (
            <span className="text-xs text-gray-500 line-through">₹{product.originalPrice.toLocaleString()}</span>
          )}
        </div>

        {discountPct > 0 && (
          <p className="text-xs text-amazon-red font-medium">{discountPct}% off</p>
        )}

        <p className="text-xs text-amazon-green mt-1">
          {product.stock > 0 ? (product.stock < 5 ? `Only ${product.stock} left!` : 'In Stock') : 'Out of Stock'}
        </p>

        <div className="mt-auto pt-3">
          <button
            onClick={() => addToCart(product, 1)}
            disabled={product.stock === 0}
            className="btn-primary w-full text-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
          </button>
        </div>
      </div>
    </div>
  );
}
